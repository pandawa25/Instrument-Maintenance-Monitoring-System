import { Outlet } from 'react-router-dom';
import { Sidebar } from './sidebar';
import { TopHeader } from './top-header';

export function DashboardLayout({ title }: { title: string }) {
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex flex-1 flex-col overflow-hidden">
        <TopHeader title={title} />
        <main className="flex-1 overflow-y-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
